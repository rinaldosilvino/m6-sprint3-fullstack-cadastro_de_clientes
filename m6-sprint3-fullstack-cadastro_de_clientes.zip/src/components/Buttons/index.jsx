import { ButtonStyle } from "./styles";

const RcButton = (props) => {
  return <ButtonStyle type="submit">{props.title}</ButtonStyle>;
};

export default RcButton;
